import express from "express"
import { CheckStatus, makeCheckout } from "../controllers/checkoutController.js";

const router = express.Router();

router.post("/create", makeCheckout);
router.post('/status',CheckStatus)
export  default router
