import mongoose from 'mongoose';

const customerInfoSchema = new mongoose.Schema({
  fullName: String,
  age: Number,
  phoneNumber: String,
  gender: String,
  email: String,
  pickupPoint:String,
   aadhaarNumber: {
    type: String,
    required: true,
    match: /^[2-9]{1}[0-9]{11}$/,
  },
});


const packageSchema = new mongoose.Schema({
  packageName: String,
  packageDate: Date,
  customers: [customerInfoSchema]
});

export const Customer = mongoose.model("Customer", packageSchema);
