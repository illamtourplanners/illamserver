import crypto from 'crypto';
import axios from 'axios';
import dotenv from "dotenv";
dotenv.config();

import { Customer } from '../model/customerSchema.js';
import { customerSchema } from '../validation/customerJoi.js';

const salt_key = '96434309-7796-489d-8924-ab56988a6076';
const merchant_id = 'PGTESTPAYUAT86';
const mobile = '9854256325';

export const makeCheckout = async (req, res) => {
  try {
    const { packageName, packageDate, customers, amount, name } = req.body;
console.log(req.body);

    // Joi validation
    const { error } = customerSchema.validate({ packageName, packageDate });
    if (error) {
      return res.status(400).json({ message: error.details[0].message });
    }

    if (!Array.isArray(customers) || customers.length === 0) {
      return res.status(400).json({
        message: 'Customer list is required and must contain at least one customer',
      });
    }

    if (!amount || !name) {
      return res.status(400).json({
        message: 'Amount and name are required for payment',
      });
    }

    // Create a unique transaction ID
    const transactionId = 'TXN_' + Date.now();

    // Prepare payload for PhonePe
    const data = {
      merchantId: merchant_id,
      merchantTransactionId: transactionId,
      name,
      amount: amount * 100, // In paise
      redirectUrl: `http://localhost:3000/api/v1/checkout/status?id=${transactionId}`,
      redirectMode: 'POST',
      mobileNumber: mobile,
      paymentInstrument: {
        type: 'PAY_PAGE',
      },
    };

    const payload = JSON.stringify(data);
    const payloadMain = Buffer.from(payload).toString('base64');
    const stringToHash = payloadMain + '/pg/v1/pay' + salt_key;
    const sha256 = crypto.createHash('sha256').update(stringToHash).digest('hex');
    const checksum = sha256 + '###1';

    const prod_URL = 'https://api-preprod.phonepe.com/apis/pg-sandbox/pg/v1/pay';

    const options = {
      method: 'POST',
      url: prod_URL,
      headers: {
        accept: 'application/json',
        'Content-Type': 'application/json',
        'X-VERIFY': checksum,
      },
      data: {
        request: payloadMain,
      },
    };

    const response = await axios(options);

    if (response.data.success !== true) {
      return res.status(400).json({ message: 'Payment initiation failed', response: response.data });
    }

    // Save customer info
    const newCheckout = new Customer({
      packageName,
      packageDate,
      customers,
      transactionId,
    });

    await newCheckout.save();

    return res.status(200).json({
      message: 'Checkout initiated',
      redirectUrl: response.data.data.instrumentResponse.redirectInfo.url,
      transactionId,
    });

  } catch (error) {
    console.error('Checkout error:', error);
    return res.status(500).json({ message: error.message });
  }
};

export const CheckStatus = (async (req, res) => {
  const merchantTransactionId = req.query.id;

  const stringToHash = `/pg/v1/status/${merchant_id}/${merchantTransactionId}` + salt_key;
  const sha256 = crypto.createHash('sha256').update(stringToHash).digest('hex');
  const checksum = sha256 + '###1';

  const options = {
    method: 'GET',
    url: `https://api-preprod.phonepe.com/apis/pg-sandbox/pg/v1/status/${merchant_id}/${merchantTransactionId}`,
    headers: {
      accept: 'application/json',
      'Content-Type': 'application/json',
      'X-VERIFY': checksum,
      'X-MERCHANT-ID': merchant_id,
    },
  };

  try {
    const response = await axios(options);
    const isSuccess = response.data.success === true;

    const redirectUrl = isSuccess
      ? `${process.env.CORS}/payment/success`
      : `${process.env.CORS}/payment/failure`;

    return res.redirect(redirectUrl);
  } catch (error) {
    console.error('Status check failed:', error);
    return res.status(500).json({ message: 'Payment status check failed' });
  }
});
